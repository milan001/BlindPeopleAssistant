package com.example.milan.blind_assistant_2;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.location.Location;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.internal.http.multipart.MultipartEntity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;

import cz.msebera.android.httpclient.HttpVersion;
import cz.msebera.android.httpclient.client.methods.HttpPost;
import cz.msebera.android.httpclient.entity.mime.HttpMultipartMode;
import cz.msebera.android.httpclient.entity.mime.MultipartEntityBuilder;
import cz.msebera.android.httpclient.entity.mime.content.FileBody;
import cz.msebera.android.httpclient.entity.mime.content.StringBody;
import cz.msebera.android.httpclient.params.BasicHttpParams;
import cz.msebera.android.httpclient.params.CoreProtocolPNames;
import cz.msebera.android.httpclient.params.HttpParams;

import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;
import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;

public class MainActivity extends AppCompatActivity{
    private GoogleMap mMap;
    private boolean mLocationPermissionGranted=false, send_gflag=false, intent_flag=true;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION=1;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS=2;
    private static final float DEFAULT_ZOOM = 10;
    public static String TAG="MY_MAP_APPLICATION";
    public Location mLastKnownLocation;
    FusedLocationProviderClient mFusedLocationProviderClient;
    SupportMapFragment mapFragment;
    LatLng mDefaultLocation;
    TextView txtSpeechInput;
    ImageButton btnSpeak;
    Intent intent;
    boolean blocked=true;
    static final int TAKE_PHOTO_CODE = 1;
    static int count=0;
    Camera mCamera;
    public static String filename;

    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);*/
            Log.d(TAG,"OnCreate");

        // Create an instance of Camera
        mCamera = getCameraInstance();
        if(mCamera==null){
            Log.d(TAG, "onCreate: camera not opened");
        }
/*        SurfaceTexture st = new SurfaceTexture(MODE_PRIVATE);
        try {
            mCamera.setPreviewTexture(st);
        } catch (IOException e) {
            e.printStackTrace();
        }*/

        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        Button send_but = (Button) findViewById(R.id.send_but);
        send_but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                send_sms();
            }
        });
        blocked=false;
        Button click_but = (Button) findViewById(R.id.click_but);
        click_but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!blocked) {
                    blocked=true;
                    Log.d(TAG, "onClick: in the onclick");

                    Camera.CameraInfo info = new Camera.CameraInfo();
                    Camera.getCameraInfo(Camera.CameraInfo.CAMERA_FACING_BACK, info);
                    int rotation = getWindowManager().getDefaultDisplay().getRotation();
                    int degrees = 0;
                    switch (rotation) {
                        case Surface.ROTATION_0:
                            degrees = 0;
                            break; //Natural orientation
                        case Surface.ROTATION_90:
                            degrees = 90;
                            break; //Landscape left
                        case Surface.ROTATION_180:
                            degrees = 180;
                            break;//Upside down
                        case Surface.ROTATION_270:
                            degrees = 270;
                            break;//Landscape right
                    }
                    int rotate = (info.orientation - degrees + 360) % 360;
                    Camera.Parameters params = mCamera.getParameters();
                    params.setRotation(rotate);
                    mCamera.setParameters(params);
                    mCamera.startPreview();
                    mCamera.takePicture(null, null, mPicture);
                }
            }
        });
    }

        private Camera.PictureCallback mPicture = new Camera.PictureCallback() {

        @Override
        public void onPictureTaken(byte[] data, Camera camera) {

            Log.d(TAG, "onPictureTaken: "+"Image taken");
            File pictureFile = getOutputMediaFile(MEDIA_TYPE_IMAGE);
            if (pictureFile == null){
                Log.d(TAG, "Error creating media file.");
                return;
            }

            try {
                FileOutputStream fos = new FileOutputStream(pictureFile);
                fos.write(data);
                fos.close();
            } catch (FileNotFoundException e) {
                Log.d(TAG, "File not found: " + e.getMessage());
            } catch (IOException e) {
                Log.d(TAG, "Error accessing file: " + e.getMessage());
            }
            Log.d(TAG, "onPictureTaken: "+"Image Stored");
            class UploadImageTask extends AsyncTask<String, Void, Void> {

                private Exception exception;

                protected Void doInBackground(String... urls) {
                    try {
                        Log.d(TAG, "onPictureTaken: "+"Starting upload");
                        String link = "http://10.10.9.118/CSL607/upload_file.php";
                        HttpParams params = new BasicHttpParams();
                        params.setParameter(CoreProtocolPNames.PROTOCOL_VERSION, HttpVersion.HTTP_1_1);
                        cz.msebera.android.httpclient.client.HttpClient mHttpClient = new cz.msebera.android.httpclient.impl.client.DefaultHttpClient(params);

                        HttpClient client = new DefaultHttpClient();
                        Log.d(TAG, "onComplete: URL1");
                        HttpPost request = new HttpPost();
                        Log.d(TAG, "onComplete: URL2");
                        request.setURI(new URI(link));
                        MultipartEntityBuilder builder = MultipartEntityBuilder.create();

                        builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);

                        builder.addPart("Title",  new StringBody("Title"));
                        builder.addPart("Nick",  new StringBody("Nick"));
                        builder.addPart("Email",  new StringBody("Email"));
                        builder.addPart("Image",  new FileBody(new File(filename)));
                        request.setEntity(builder.build());
//                                request.setURI(new URI(link));
                        Log.d(TAG, "onComplete: URL3");
                        cz.msebera.android.httpclient.HttpResponse response = mHttpClient.execute(request);
                        Log.d(TAG, "onComplete: URL3");
                        BufferedReader in = new BufferedReader(new
                                InputStreamReader(response.getEntity().getContent()));

                        StringBuffer sb = new StringBuffer("");
                        String line="";
                        Log.d(TAG, "onComplete: URL4");

                        while ((line = in.readLine()) != null) {
                            sb.append(line);
                            break;
                        }

                        Log.d(TAG, "M:"+sb.toString());
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (URISyntaxException e) {
                        e.printStackTrace();
                    }
                    mediaPlayer = new MediaPlayer();
                    if(mediaPlayer!=null) {
                        try {
                            mediaPlayer.release();
                        }
                        catch(Exception e) {
                            e.printStackTrace();
                        }
                    }
                    try {
                        mediaPlayer.setDataSource("10.10.9.118/CSL607/audio.mp3");
                        mediaPlayer.prepare();
                        mediaPlayer.start();
                    } catch (IOException e) {
                        Log.d(TAG, "doInBackground: "+"some error");
                    }
                    blocked=false;
                    return null;
                }
            }
            new UploadImageTask().execute("blaa");
        }
    };
    private static Uri getOutputMediaFileUri(int type){
        return Uri.fromFile(getOutputMediaFile(type));
    }

    private static File getOutputMediaFile(int type){
        Log.d(TAG, "getOutputMediaFile: entered...");
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.

        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), "MyCameraApp");
        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (! mediaStorageDir.exists()){
            if (! mediaStorageDir.mkdirs()){
                Log.d("MyCameraApp", "failed to create directory");
                return null;
            }
        }

        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File mediaFile;
        if (type == MEDIA_TYPE_IMAGE){
            mediaFile = new File(mediaStorageDir.getPath() + File.separator +
                    "IMG_"+ timeStamp + ".jpg");
            filename=mediaStorageDir.getPath() + File.separator +
                    "IMG_"+ timeStamp + ".jpg";
        } else if(type == MEDIA_TYPE_VIDEO) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator +
                    "VID_"+ timeStamp + ".mp4");
            filename=mediaStorageDir.getPath() + File.separator +
                    "VID_"+ timeStamp + ".mp4";
        } else {
            return null;
        }

        return mediaFile;
    }



    public static Camera getCameraInstance(){
        Camera c = null;
        try {
            c = Camera.open(); // attempt to get a Camera instance
            Log.d(TAG, "getCameraInstance: "+"camera opening...");
        }
        catch (Exception e){
            Log.d(TAG, "getCameraInstance: "+"camera not found");
            // Camera is not available (in use or does not exist)
        }
        return c; // returns null if camera is unavailable
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        mLocationPermissionGranted = false;
        switch (requestCode) {
            case PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    mLocationPermissionGranted = true;
                }
            }
        }
    }
    private void getLocationPermission() {
    /*
     * Request location permission, so that we can get the location of the
     * device. The result of the permission request is handled by a callback,
     * onRequestPermissionsResult.
     */
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mLocationPermissionGranted = true;
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }
    private void send_sms(){
        Log.d(TAG, "send_sms: ");
        try {
            if (mLocationPermissionGranted) {
                Task locationResult = mFusedLocationProviderClient.getLastLocation();
                locationResult.addOnCompleteListener(this, new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "send_sms: "+"got last location");
                            // Set the map's camera position to the current location of the device.
                            mLastKnownLocation = (Location) task.getResult();
                            Log.d(TAG, "Current location in send"+mLastKnownLocation.getLatitude()+", "+
                                    mLastKnownLocation.getLongitude());
                            String link = "http://192.168.43.39/CSL607/mail.php?long="+mLastKnownLocation.getLongitude()+"&lati="+mLastKnownLocation.getLatitude()+"&user=Temp";
                            class RetrieveFeedTask extends AsyncTask<String, Void, Void> {

                                private Exception exception;

                                protected Void doInBackground(String... urls) {
                                    try {
                                        String link = "http://10.10.9.118/CSL607/mail.php?long="+mLastKnownLocation.getLongitude()+"&lati="+mLastKnownLocation.getLatitude()+"&user=Temp";
                                        HttpClient client = new DefaultHttpClient();
                                        Log.d(TAG, "onComplete: URL1");
                                        HttpGet request = new HttpGet();
                                        Log.d(TAG, "onComplete: URL2");
                                        request.setURI(new URI(link));
//                                request.setURI(new URI(link));
                                        Log.d(TAG, "onComplete: URL3");
                                        HttpResponse response = client.execute(request);
                                        Log.d(TAG, "onComplete: URL3");
                                        BufferedReader in = new BufferedReader(new
                                                InputStreamReader(response.getEntity().getContent()));

                                        StringBuffer sb = new StringBuffer("");
                                        String line="";
                                        Log.d(TAG, "onComplete: URL4");

                                        while ((line = in.readLine()) != null) {
                                            sb.append(line);
                                            break;
                                        }
                                        Log.d(TAG, "onComplete: Message-url: "+sb.toString());
                                    } catch (UnsupportedEncodingException e) {
                                        e.printStackTrace();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    } catch (URISyntaxException e) {
                                        e.printStackTrace();
                                    }
                                    return null;
                                }
                            }
                            new RetrieveFeedTask().execute(link);
                        } else {
                            Log.d(TAG, "Current location is null. Using defaults in send.");
                        }
                    }
                });
            }else{
                mLastKnownLocation = null;
                getLocationPermission();
                send_sms();
            }
        } catch(SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }
}