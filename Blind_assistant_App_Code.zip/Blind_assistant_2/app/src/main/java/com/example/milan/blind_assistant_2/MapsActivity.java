package com.example.milan.blind_assistant_2;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.drm.DrmStore;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;

import org.apache.http.client.HttpClient;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.client.methods.HttpPost;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.ThemedSpinnerAdapter;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.location.LocationServices;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;

import org.apache.http.HttpResponse;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Locale;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private boolean mLocationPermissionGranted=false, send_gflag=false, intent_flag=true;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION=1;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS=2;
    private static final float DEFAULT_ZOOM = 10;
    public String TAG="MY_MAP_APPLICATION";
    public Location mLastKnownLocation;
    FusedLocationProviderClient mFusedLocationProviderClient;
    SupportMapFragment mapFragment;
    LatLng mDefaultLocation;
    TextView txtSpeechInput;
    ImageButton btnSpeak;
    Intent intent;
    boolean blocked=true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        Log.d(TAG,"OnCreate");
        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        intent = getIntent();
        intent= new Intent(Intent.ACTION_SENDTO);
  //      if (Intent.ACTION_SENDTO.equals(intent.getAction())) {
            // Turn on the My Location layer and the related control on the map.
//            updateLocationUI();

            // Get the current location of the device and set the position of the map.
//            getDeviceLocation();

//            Log.d(TAG, "onCreate: "+mLastKnownLocation.getAltitude()+", "+mLastKnownLocation.getLatitude()+", "+mLastKnownLocation.getLongitude());
    //    }
//        promptSpeechInput();
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
/*        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
*/

    }
    private void promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                "Say something&#8230");
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    "Sorry! Your device doesn\\'t support speech input",
                    Toast.LENGTH_SHORT).show();
        }
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        blocked=true;

        Log.d(TAG,"OnMapReady");
        mMap = googleMap;
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        mDefaultLocation = new LatLng(-33.852, 151.211);

        // Turn on the My Location layer and the related control on the map.
        updateLocationUI();

        // Get the current location of the device and set the position of the map.
        getDeviceLocation();
        if(Intent.ACTION_SENDTO.equals(intent.getAction())){
//            intent_flag=false;
            send_sms();
        }


        // Add a marker in Sydney and move the camera
/*        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        */
    }

    private void getLocationPermission() {
    /*
     * Request location permission, so that we can get the location of the
     * device. The result of the permission request is handled by a callback,
     * onRequestPermissionsResult.
     */
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mLocationPermissionGranted = true;
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        mLocationPermissionGranted = false;
        switch (requestCode) {
            case PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    mLocationPermissionGranted = true;
                }
            }
            case MY_PERMISSIONS_REQUEST_SEND_SMS: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "send_sms_message: "+"permission granted");
                    if(send_gflag)
                        send_sms_message();
                } else {
                    Toast.makeText(getApplicationContext(),
                            "SMS faild, please try again.", Toast.LENGTH_LONG).show();
                    return;
                }
            }
        }
        updateLocationUI();
    }
    private void updateLocationUI() {
        if (mMap == null) {
            return;
        }
        try {
            if (mLocationPermissionGranted) {
                mMap.setMyLocationEnabled(true);
                mMap.getUiSettings().setMyLocationButtonEnabled(true);
            } else {
                mMap.setMyLocationEnabled(false);
                mMap.getUiSettings().setMyLocationButtonEnabled(false);
                mLastKnownLocation = null;
                getLocationPermission();
            }
        } catch (SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    private void getDeviceLocation() {
    /*
     * Get the best and most recent location of the device, which may be null in rare
     * cases when a location is not available.
     */
        try {
            if (mLocationPermissionGranted) {
                Task locationResult = mFusedLocationProviderClient.getLastLocation();
                locationResult.addOnCompleteListener(this, new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if (task.isSuccessful()) {
                            // Set the map's camera position to the current location of the device.
                            mLastKnownLocation = (Location) task.getResult();
                            mDefaultLocation=new LatLng(mLastKnownLocation.getLatitude(),
                                    mLastKnownLocation.getLongitude());
                            Log.d(TAG, "Current location is not null.");
                            blocked=true;
                            mMap.addMarker(new MarkerOptions().position(mDefaultLocation).title("Your Location"));
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(
                                    mDefaultLocation,DEFAULT_ZOOM));
                        } else {
                            Log.d(TAG, "Current location is null. Using defaults.");
                            Log.e(TAG, "Exception: %s", task.getException());
                            mMap.addMarker(new MarkerOptions().position(mDefaultLocation).title("Your Location"));
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mDefaultLocation,DEFAULT_ZOOM));
                            //mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mDefaultLocation, DEFAULT_ZOOM));
                            mMap.getUiSettings().setMyLocationButtonEnabled(false);
                        }
                    }
                });
            }
        } catch(SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    private void send_sms(){
        Log.d(TAG, "send_sms: ");
        try {
            if (mLocationPermissionGranted) {
                Task locationResult = mFusedLocationProviderClient.getLastLocation();
                locationResult.addOnCompleteListener(this, new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "send_sms: "+"got last location");
                            // Set the map's camera position to the current location of the device.
                            mLastKnownLocation = (Location) task.getResult();
                            mDefaultLocation=new LatLng(mLastKnownLocation.getLatitude(),
                                    mLastKnownLocation.getLongitude());
                            Log.d(TAG, "Current location in send"+mLastKnownLocation.getLatitude()+", "+
                                    mLastKnownLocation.getLongitude());

                            String link = "http://192.168.43.39/CSL607/mail.php?long="+mLastKnownLocation.getLongitude()+"&lati="+mLastKnownLocation.getLatitude()+"&user=Temp";
                            class RetrieveFeedTask extends AsyncTask<String, Void, Void> {

                                private Exception exception;

                                protected Void doInBackground(String... urls) {
                                    try {
                                        String link = "http://10.10.9.252/CSL607/mail.php?long="+mLastKnownLocation.getLongitude()+"&lati="+mLastKnownLocation.getLatitude()+"&user=Temp";

                                        HttpClient client = new DefaultHttpClient();
                                        Log.d(TAG, "onComplete: URL1");
                                        HttpGet request = new HttpGet();
                                        Log.d(TAG, "onComplete: URL2");
                                        request.setURI(new URI(link));
//                                request.setURI(new URI(link));
                                        Log.d(TAG, "onComplete: URL3");
                                        HttpResponse response = client.execute(request);
                                        Log.d(TAG, "onComplete: URL3");
                                        BufferedReader in = new BufferedReader(new
                                                InputStreamReader(response.getEntity().getContent()));

                                        StringBuffer sb = new StringBuffer("");
                                        String line="";
                                        Log.d(TAG, "onComplete: URL4");

                                        while ((line = in.readLine()) != null) {
                                            sb.append(line);
                                            break;
                                        }
                                        Log.d(TAG, "onComplete: Message-url: "+sb.toString());
                                    } catch (UnsupportedEncodingException e) {
                                        e.printStackTrace();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    } catch (URISyntaxException e) {
                                        e.printStackTrace();
                                    }
                                    return null;
                                }
                            }
                            new RetrieveFeedTask().execute(link);
/*
                            send_gflag=true;
                            send_sms_message();
*/

                            //PackageManager pm=getPackageManager();
                            //intent = new Intent(Intent.ACTION_VIEW);
                            //intent.setData(Uri.parse("http://api.whatsapp.com/send?phone=+918725811012&text=sample"));
/*                            try {
                                String link = "http://192.168.43.39/CSL607/mail.php?long="+mLastKnownLocation.getLongitude()+"&lati="+mLastKnownLocation.getLatitude()+"&user=Temp";

                                URL url = new URL(link);
                                Log.d(TAG, "onComplete: URL1");
                                HttpClient client = new DefaultHttpClient();

                                HttpPost request = new HttpPost(link);
                                Log.d(TAG, "onComplete: URL2");
//                                request.setURI(new URI(link));
                                Log.d(TAG, "onComplete: URL3");
                                HttpResponse response = client.execute(request);
                                Log.d(TAG, "onComplete: URL3");
                                BufferedReader in = new BufferedReader(new
                                        InputStreamReader(response.getEntity().getContent()));

                                StringBuffer sb = new StringBuffer("");
                                String line="";
                                Log.d(TAG, "onComplete: URL4");

                                while ((line = in.readLine()) != null) {
                                    sb.append(line);
                                    break;
                                }
                                Log.d(TAG, "onComplete: Message-url: "+sb.toString());
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }*/
                            /*                                URL url = new URL("10.10.9.252/CSL607/mail.php");
                                String data  = null;
                                data = URLEncoder.encode("long", "UTF-8")
                                        + "=" + URLEncoder.encode(Double.toString(mLastKnownLocation.getLongitude()), "UTF-8");
                                data += "&" + URLEncoder.encode("lati", "UTF-8")
                                        + "=" + URLEncoder.encode(Double.toString(mLastKnownLocation.getLatitude()), "UTF-8");
                                data += "&" + URLEncoder.encode("user", "UTF-8")
                                        + "=" + URLEncoder.encode("User_temp", "UTF-8");
                                URLConnection conn = url.openConnection();
                                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                                wr.write( data );
                                wr.flush();
                                BufferedReader reader = new BufferedReader(new
                                        InputStreamReader(conn.getInputStream()));


                                StringBuilder sb = new StringBuilder();
                                String line = null;

                                // Read Server Response
                                while((line = reader.readLine()) != null) {
                                    sb.append(line);
                                    break;
                                }
*/

                            //PackageInfo info=pm.getPackageInfo("com.whatsapp", PackageManager.GET_META_DATA);
                            //intent.setPackage("com.whatsapp");
                            //intent.setData(Uri.parse("smsto:8725811012"));
                            //intent.putExtra("address"  , "8725811012");
                            //intent.setType("text/plain");

                            /*intent.putExtra(Intent.EXTRA_TEXT, mLastKnownLocation.getLatitude()+", "+
                                    mLastKnownLocation.getLongitude());*/
                            //startActivity(intent);

/*                            intent.setData(Uri.parse("smsto: 8725811012"));
                            intent.putExtra("sms_body", mLastKnownLocation.getLatitude()+", "+
                                    mLastKnownLocation.getLongitude());
                            //intent.setType("vnd.android-dir/mms-sms");
                            //intent.putExtra("address"  , "8725811012");
                            if (intent.resolveActivity(getPackageManager()) != null) {
                                startActivity(intent);
                                //finish();
                                Log.d(TAG, "onComplete: "+"sent message");
                            }
*/
/*                            intent.putExtra("sms_body", mLastKnownLocation.getLatitude()+", "+
                                    mLastKnownLocation.getLongitude());
                            //intent.setType("vnd.android-dir/mms-sms");
                            intent.setType("text/plain");
                            //startActivity(intent);
                            Log.d(TAG, "onComplete: "+"sent message");*/

                        } else {
                            Log.d(TAG, "Current location is null. Using defaults in send.");
                        }
                    }
                });
            }else{
                updateLocationUI();
                send_sms();
            }
        } catch(SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    private void send_sms_message(){
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "send_sms_message: "+"ask permission");
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        }else{
            Log.d(TAG, "send_sms_message: "+"sending...");
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("8725811012", null, "Set text", null, null);
            Log.d(TAG, "send_sms_message: "+"sent");
        }
    }

/*    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.option_get_place) {
            showCurrentPlace();
        }
        return true;
    }
*/
}

